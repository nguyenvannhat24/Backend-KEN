const mongoose = require('mongoose');
const { Schema } = mongoose;

const allowedRoles = ["Người tạo", "Quản trị viên", "Người xem"]; 

const GroupMemberSchema = new Schema({
  group_id: { type: Schema.Types.ObjectId, ref: 'Group', required: true, index: true },
  user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  role_in_group: {
    type: String,
    enum: allowedRoles, 
    maxlength: 50,
    default: "Người xem", 
  },
}, { collection: 'GroupMembers', timestamps: true });

module.exports = mongoose.model('GroupMember', GroupMemberSchema);